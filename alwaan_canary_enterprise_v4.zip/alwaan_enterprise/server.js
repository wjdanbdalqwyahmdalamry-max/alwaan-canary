const express=require('express'); const cors=require('cors'); const path=require('path');
const app=express(); app.use(cors()); app.use(express.json({limit:'2mb'}));
app.use(express.static(path.join(__dirname,'public')));
app.get('/api/health',(req,res)=>res.json({ok:true,system:'Alwaan Canary Enterprise',version:'4.0.0'}));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
const port=process.env.PORT||3000; app.listen(port,()=>console.log(`Alwaan Canary Enterprise running on ${port}`));
